/* ===== SENAI Workshop 2026 — lógica do site ===== */
(function () {
  "use strict";
  var S = window.SITE;

  var I18N = {
    pt: {
      theme: "Tema", back: "← Voltar", eyebrow: "São Carlos · Tecnologia em Ação",
      heroTitle: 'Workshop SENAI <span class="grad">2026</span>',
      heroSub: "Mecatrônica e Desenvolvimento de Sistemas",
      seeClasses: "Conheça as turmas",
      classesTitle: "Turmas SENAI São Carlos 2026",
      classesSub: "Dois cursos, dezenas de ideias que viram solução.",
      projects: "Projetos", students: "Alunos", seeProjects: "Ver Projetos",
      aboutTitle: "Sobre o SENAI São Carlos",
      aboutText: "O SENAI São Carlos é referência em formação técnica e tecnológica na região, preparando profissionais para os desafios da Indústria 4.0. Nossos alunos desenvolvem projetos inovadores que conectam teoria e prática, criando soluções reais para problemas do mercado de trabalho.",
      statProjects: "Projetos Desenvolvidos", statStudents: "Alunos Participantes", statCourses: "Cursos Participantes", statDedication: "Dedicação e Inovação",
      ourProjects: "Nossos Projetos", ourProjectsSub: "Landing page, pitch técnico e pitch comercial de cada grupo.",
      tech: "Funcionamento", commercial: "Comercial", visit: "Visitar site", soon: "Em breve",
      members: "integrantes",
      fTitle: "SENAI São Carlos", fText: "Centro de referência em formação técnica e tecnológica, preparando profissionais para os desafios da Indústria 4.0.", fSlogan: "Formando o futuro da tecnologia",
      fClasses: "Turmas 2026", fTeam: "Equipe de Desenvolvimento", fDevs: "Desenvolvedores:", techLead: "Tech Lead",
      rights: "Serviço Nacional de Aprendizagem Industrial", copyright: "Todos os direitos reservados", devBy: "Desenvolvido por",
      noProjects: "Nenhum projeto cadastrado ainda.",
      soonMsg: "Link disponível em breve."
    },
    en: {
      theme: "Theme", back: "← Back", eyebrow: "São Carlos · Technology in Action",
      heroTitle: 'SENAI Workshop <span class="grad">2026</span>',
      heroSub: "Mechatronics and Systems Development",
      seeClasses: "Meet the classes",
      classesTitle: "SENAI São Carlos Classes 2026",
      classesSub: "Two courses, dozens of ideas turned into solutions.",
      projects: "Projects", students: "Students", seeProjects: "See Projects",
      aboutTitle: "About SENAI São Carlos",
      aboutText: "SENAI São Carlos is a regional reference in technical and technological education, preparing professionals for the challenges of Industry 4.0. Our students develop innovative projects that connect theory and practice, creating real solutions for real market problems.",
      statProjects: "Projects Developed", statStudents: "Participating Students", statCourses: "Participating Courses", statDedication: "Dedication & Innovation",
      ourProjects: "Our Projects", ourProjectsSub: "Landing page, technical pitch and commercial pitch of each group.",
      tech: "How it works", commercial: "Commercial", visit: "Visit site", soon: "Coming soon",
      members: "members",
      fTitle: "SENAI São Carlos", fText: "A reference center in technical and technological education, preparing professionals for the challenges of Industry 4.0.", fSlogan: "Shaping the future of technology",
      fClasses: "Classes 2026", fTeam: "Development Team", fDevs: "Developers:", techLead: "Tech Lead",
      rights: "National Service for Industrial Training", copyright: "All rights reserved", devBy: "Developed by",
      noProjects: "No projects registered yet.",
      soonMsg: "Link coming soon."
    }
  };

  /* ----- estado (tema / idioma) ----- */
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  var lang = store("lang") || "pt";
  var theme = store("theme") || "dark";
  function applyTheme() { document.documentElement.setAttribute("data-theme", theme); }
  applyTheme();

  function T(k) { return (I18N[lang] && I18N[lang][k]) || k; }
  function tr(x) { return x && typeof x === "object" ? (x[lang] || x.pt || "") : (x || ""); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function safeUrl(u) { u = String(u || "").trim(); return /^(https?:\/\/|\.{0,2}\/|#)/i.test(u) ? u : ""; }

  var cursos = Object.keys(S.cursos).map(function (k) { return S.cursos[k]; });
  function totalProj(c) { return c.projetos.length; }
  function totalAlunos(c) { return c.projetos.reduce(function (a, p) { return a + (Number(p.alunos) || 0); }, 0); }
  function fmt(n) { return n > 0 ? n : "—"; }

  /* ----- header ----- */
  function headerHTML(isCourse) {
    var home = isCourse ? "../index.html" : "index.html";
    return '<header class="header"><div class="container">' +
      (isCourse
        ? '<a class="btn-ghost back" href="' + home + '">' + T("back") + '</a>'
        : '<a class="logo" href="' + home + '">SEN<span>AI</span></a>') +
      '<div class="header-actions">' +
      '<button class="btn-ghost" id="themeBtn">' + T("theme") + ' ' + (theme === "dark" ? "☀" : "☾") + '</button>' +
      '<button class="btn-ghost" id="langBtn">' + (lang === "pt" ? "EN" : "PT") + '</button>' +
      '</div></div></header>';
  }

  /* ----- footer ----- */
  function personHTML(p, role) {
    var links = "";
    if (safeUrl(p.instagram)) links += '<a href="' + esc(safeUrl(p.instagram)) + '" target="_blank" rel="noopener">Instagram</a>';
    if (safeUrl(p.github)) links += '<a href="' + esc(safeUrl(p.github)) + '" target="_blank" rel="noopener">GitHub</a>';
    return '<div class="person"><b>' + esc(p.nome) + '</b>' + (role ? '<small>' + role + '</small><br>' : '') + links + '</div>';
  }
  function footerHTML() {
    var eq = S.equipe || {};
    var team = "";
    if (eq.lider) team += personHTML(eq.lider, T("techLead"));
    if (eq.devs && eq.devs.length) team += '<p style="margin:12px 0 8px">' + T("fDevs") + '</p>' + eq.devs.map(function (d) { return personHTML(d); }).join("");
    return '<footer class="footer"><div class="container"><div class="footer-grid">' +
      '<div><h4>' + T("fTitle") + '</h4><p>' + T("fText") + '</p><strong class="tf">' + T("fSlogan") + '</strong></div>' +
      '<div><h4>' + T("fClasses") + '</h4><ul>' + cursos.map(function (c) { return '<li>' + esc(tr(c.nome)) + ' — ' + esc(tr(c.turma)) + '</li>'; }).join("") + '</ul></div>' +
      (team ? '<div><h4>' + T("fTeam") + '</h4>' + team + '</div>' : '') +
      '</div><div class="copy"><strong>SENAI São Carlos</strong> - ' + T("rights") + '<br>© ' + S.ano + ' ' + T("copyright") +
      (eq.lider && eq.lider.nome ? '<br>' + T("devBy") + ' ' + esc(eq.lider.nome) : '') + '</div></div></footer>';
  }

  /* ----- HOME ----- */
  function renderHome(root) {
    var np = 0, na = 0;
    cursos.forEach(function (c) { np += totalProj(c); na += totalAlunos(c); });
    var cards = Object.keys(S.cursos).map(function (k) {
      var c = S.cursos[k];
      var sigla = k === "ds" ? "DS" : "MEC";
      return '<article class="class-card reveal">' +
        '<div class="class-img"><img src="' + esc(c.imagem) + '" alt="' + esc(tr(c.nome)) + '" loading="lazy"><span class="badge">' + sigla + '</span></div>' +
        '<div class="class-body"><h3>' + esc(tr(c.nome)) + ' · ' + esc(tr(c.turma)) + '</h3><p>' + esc(tr(c.descricao)) + '</p>' +
        '<div class="stats-row"><div><b>' + totalProj(c) + '</b><span>' + T("projects") + '</span></div><div><b>' + fmt(totalAlunos(c)) + '</b><span>' + T("students") + '</span></div></div>' +
        '<a class="btn" href="' + esc(c.pagina) + '">' + T("seeProjects") + '</a></div></article>';
    }).join("");

    root.innerHTML = headerHTML(false) +
      '<section class="hero"><div class="container"><span class="eyebrow">' + T("eyebrow") + '</span>' +
      '<h1>' + T("heroTitle") + '</h1><p class="sub">' + T("heroSub") + '</p>' +
      '<a class="btn" href="#turmas">' + T("seeClasses") + '</a></div></section>' +
      '<section class="section" id="turmas"><div class="container"><h2 class="section-title">' + T("classesTitle") + '</h2><p class="section-sub">' + T("classesSub") + '</p><div class="class-grid">' + cards + '</div></div></section>' +
      '<section class="section about"><div class="container"><h2 class="section-title">' + T("aboutTitle") + '</h2><br><p class="about-text">' + T("aboutText") + '</p>' +
      '<div class="stat-grid">' +
      '<div class="stat reveal"><b>' + np + '</b><span>' + T("statProjects") + '</span></div>' +
      '<div class="stat reveal"><b>' + fmt(na) + '</b><span>' + T("statStudents") + '</span></div>' +
      '<div class="stat reveal"><b>' + cursos.length + '</b><span>' + T("statCourses") + '</span></div>' +
      '<div class="stat reveal"><b>100%</b><span>' + T("statDedication") + '</span></div></div></div></section>' +
      footerHTML();
  }

  /* ----- PÁGINA DE CURSO ----- */
  var timer = null, current = 0;
  function renderCourse(root, key) {
    var c = S.cursos[key];
    var P = c.projetos;
    document.title = "SENAI - " + tr(c.nome) + " " + S.ano;

    var chips = P.map(function (p, i) { return '<button class="chip' + (i === 0 ? " active" : "") + '" data-go="' + i + '">' + esc(p.nome) + '</button>'; }).join("");

    var slides = P.map(function (p, i) {
      var img = safeUrl(p.imagem) || c.imagem;
      var has = !!img;
      return '<article class="slide' + (i === 0 ? " active" : "") + (has ? "" : " noimg") + '">' +
        '<div class="slide-bg"' + (has ? ' style="background-image:url(\'' + esc(img) + '\')"' : '') + '></div>' +
        '<div class="slide-content"><span class="tag">' + esc(p.nome) + '</span>' +
        '<h1><a class="slide-link" ' + (safeUrl(p.landing) ? 'href="' + esc(safeUrl(p.landing)) + '" target="_blank" rel="noopener"' : 'href="#" data-empty="1"') + '>' + esc(p.nome) + ' <span class="go">↗</span></a></h1>' +
        '<h2>' + esc(p.subtitulo) + '</h2></div></article>';
    }).join("");

    var dots = P.map(function (_, i) { return '<button class="dot' + (i === 0 ? " active" : "") + '" data-go="' + i + '" aria-label="Projeto ' + (i + 1) + '"></button>'; }).join("");

    function act(url, label, primary) {
      var u = safeUrl(url);
      return u
        ? '<a class="act' + (primary ? " primary" : "") + '" href="' + esc(u) + '" target="_blank" rel="noopener">' + label + '</a>'
        : '<a class="act' + (primary ? " primary" : "") + '" href="#" data-empty="1">' + label + '</a>';
    }
    var cards = P.map(function (p, i) {
      var u = safeUrl(p.imagem);
      return '<article class="project-card reveal" id="proj-' + i + '">' +
        '<div class="project-img">' + (u ? '<img src="' + esc(u) + '" alt="' + esc(p.nome) + '" loading="lazy">' : '<span class="ph">' + esc((p.nome || "?").charAt(0)) + '</span>') + '</div>' +
        '<div class="project-body"><span class="pname">' + esc(p.nome) + '</span><h3>' + esc(p.subtitulo) + '</h3><p>' + esc(p.descricao) + '</p>' +
        (Number(p.alunos) > 0 ? '<span class="meta">' + p.alunos + ' ' + T("members") + '</span>' : '') +
        '<div class="actions">' + act(p.funcionamento, T("tech")) + act(p.comercial, T("commercial")) + act(p.landing, T("visit"), true) + '</div></div></article>';
    }).join("");

    root.innerHTML = headerHTML(true) +
      '<nav class="project-nav"><div class="container">' + chips + '</div></nav>' +
      '<section class="carousel" id="carousel">' + slides +
      '<button class="arrow prev" aria-label="Anterior">‹</button><button class="arrow next" aria-label="Próximo">›</button>' +
      '<div class="dots">' + dots + '</div><a class="scroll-down" href="#projetos" aria-label="Descer">↓</a></section>' +
      '<section class="section" id="projetos"><div class="container"><h2 class="section-title">' + T("ourProjects") + '</h2><p class="section-sub">' + T("ourProjectsSub") + '</p>' +
      (P.length ? '<div class="project-grid">' + cards + '</div>' : '<p class="section-sub">' + T("noProjects") + '</p>') + '</div></section>' +
      footerHTML();

    initCarousel(P.length);
  }

  function go(i, n) {
    var slides = document.querySelectorAll(".slide"), dots = document.querySelectorAll(".dot"), chips = document.querySelectorAll(".chip");
    current = (i + n) % n;
    [slides, dots, chips].forEach(function (list) {
      list.forEach(function (el, idx) { el.classList.toggle("active", idx === current); });
    });
    var chip = chips[current];
    if (chip && chip.scrollIntoView) chip.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
  }
  function initCarousel(n) {
    if (!n) return;
    current = 0;
    var car = document.getElementById("carousel");
    /* Autoplay contínuo: passa de projeto em projeto a cada AUTOPLAY_MS (não pausa com o mouse).
       Quando você clica numa seta/bolinha/nome, o tempo reinicia e ele continua sozinho. */
    var AUTOPLAY_MS = 5000;
    function restart() { clearInterval(timer); timer = setInterval(function () { go(current + 1, n); }, AUTOPLAY_MS); }
    restart();
    car.querySelector(".prev").onclick = function () { go(current - 1 + n, n); restart(); };
    car.querySelector(".next").onclick = function () { go(current + 1, n); restart(); };
    document.querySelectorAll("[data-go]").forEach(function (b) {
      b.onclick = function () {
        var i = Number(b.getAttribute("data-go"));
        go(i, n); restart();
        if (b.classList.contains("chip")) {
          var card = document.getElementById("proj-" + i);
          if (card) { card.scrollIntoView({ behavior: "smooth", block: "center" }); card.classList.remove("flash"); void card.offsetWidth; card.classList.add("flash"); }
        }
      };
    });
    var x0 = null;
    car.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    car.addEventListener("touchend", function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) { go(current + (dx < 0 ? 1 : -1) + n, n); restart(); }
      x0 = null;
    }, { passive: true });
    document.onkeydown = function (e) {
      if (e.key === "ArrowLeft") { go(current - 1 + n, n); restart(); }
      if (e.key === "ArrowRight") { go(current + 1, n); restart(); }
    };
  }

  /* ----- aviso para botões ainda sem link ----- */
  var toastTimer = null;
  function showToast(msg) {
    var t = document.getElementById("toast");
    if (!t) { t = document.createElement("div"); t.id = "toast"; t.className = "toast"; document.body.appendChild(t); }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2200);
  }
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a[data-empty]") : null;
    if (a) { e.preventDefault(); showToast(T("soonMsg")); }
  });

  /* ----- reveal on scroll ----- */
  function initReveal() {
    var els = document.querySelectorAll(".reveal");
    if (!("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("in"); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ----- boot ----- */
  function render() {
    var root = document.getElementById("app");
    document.documentElement.lang = lang === "pt" ? "pt-BR" : "en";
    var page = document.body.getAttribute("data-page");
    if (page === "home") renderHome(root); else renderCourse(root, page);
    document.getElementById("themeBtn").onclick = function () { theme = theme === "dark" ? "light" : "dark"; store("theme", theme); applyTheme(); render(); };
    document.getElementById("langBtn").onclick = function () { lang = lang === "pt" ? "en" : "pt"; store("lang", lang); render(); };
    initReveal();
  }
  render();
})();
